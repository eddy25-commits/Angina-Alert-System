# Changed files manifest

## Modified (already existed in your uploaded repo)

- `.env.example`
- `PROJECT_PROGRESS.md`
- `README.md`
- `docs/DATABASE.md`
- `package.json`
- `src/app/app/alerts/[id]/page.tsx`
- `src/app/app/alerts/actions.ts`
- `src/app/app/layout.tsx`
- `src/app/app/page.tsx`
- `src/app/app/pair/actions.ts`
- `src/app/app/profile/page.tsx`
- `src/lib/notifications.test.ts`
- `src/lib/notifications.ts`
- `src/lib/supabase/types.ts`
- `supabase/APPLYING_MIGRATIONS.md`

## New files

- `docs/MANUAL_TEST_PLAN.md`
- `public/offline.html`
- `src/app/api/notifications/unsubscribe/route.ts`
- `src/app/app/alerts/__tests__/status.test.ts`
- `src/app/app/contacts/ContactForm.tsx`
- `src/app/app/contacts/[id]/DeleteContactButton.tsx`
- `src/app/app/contacts/[id]/EditContactForm.tsx`
- `src/app/app/contacts/[id]/page.tsx`
- `src/app/app/contacts/actions.ts`
- `src/app/app/contacts/new/page.tsx`
- `src/app/app/contacts/page.tsx`
- `src/app/app/dashboard/page.tsx`
- `src/app/app/episodes/EpisodeForm.tsx`
- `src/app/app/episodes/[id]/DeleteEpisodeButton.tsx`
- `src/app/app/episodes/[id]/EditEpisodeForm.tsx`
- `src/app/app/episodes/[id]/MedicationTakenPanel.tsx`
- `src/app/app/episodes/[id]/page.tsx`
- `src/app/app/episodes/actions.ts`
- `src/app/app/episodes/new/page.tsx`
- `src/app/app/episodes/page.tsx`
- `src/app/app/medications/MedicationForm.tsx`
- `src/app/app/medications/[id]/DeleteMedicationButton.tsx`
- `src/app/app/medications/[id]/EditMedicationForm.tsx`
- `src/app/app/medications/[id]/page.tsx`
- `src/app/app/medications/actions.ts`
- `src/app/app/medications/new/page.tsx`
- `src/app/app/medications/page.tsx`
- `src/components/NotificationSetup.tsx`
- `src/components/OfflineBanner.tsx`
- `src/lib/__tests__/errorMessages.test.ts`
- `src/lib/__tests__/tags.test.ts`
- `src/lib/errorMessages.ts`
- `src/lib/tags.ts`
- `supabase/migrations/0005_episode_logging.sql`
- `supabase/migrations/0006_medications.sql`
- `supabase/migrations/0007_emergency_contacts.sql`
- `supabase/migrations/0008_hardening.sql`
- `tests/integration/helpers.ts`
- `tests/integration/security.test.ts`
- `vitest.config.mts`
- `vitest.integration.config.mts`

Total: 15 modified, 41 new = 56 files.