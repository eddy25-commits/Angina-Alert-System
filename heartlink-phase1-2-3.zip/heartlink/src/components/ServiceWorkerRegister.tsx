"use client";

import { useEffect } from "react";

/**
 * Registers the service worker that makes HeartLink installable and,
 * in Phase 4, able to receive Web Push notifications.
 *
 * This only registers the worker — it does not fake push behavior.
 * Push subscription logic is implemented in Phase 4.
 */
export default function ServiceWorkerRegister() {
  useEffect(() => {
    if (typeof window === "undefined") return;
    if (!("serviceWorker" in navigator)) return;

    navigator.serviceWorker.register("/sw.js").catch((err) => {
      // Registration failures must be visible during development, not swallowed.
      console.error("HeartLink: service worker registration failed", err);
    });
  }, []);

  return null;
}
