// HeartLink service worker — foundation.
// This file intentionally does NOT implement push notification handling yet.
// That is Phase 4 (Push Notifications) work and will be added when the
// push subscription + Web Push send pipeline is built and tested.

self.addEventListener("install", () => {
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(self.clients.claim());
});

// No fetch handler yet: we do not want to silently serve stale/fake
// content for a safety-critical app before real offline handling
// (Phase 9) is designed and tested.
